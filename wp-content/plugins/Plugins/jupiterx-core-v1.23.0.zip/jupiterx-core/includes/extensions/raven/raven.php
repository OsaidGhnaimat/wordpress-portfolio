<?php
/**
 * Raven extension main file.
 *
 * @package JupiterX_Core_Raven_Extension
 */

defined( 'ABSPATH' ) || die();

define( 'JUPITERX_CORE_RAVEN__FILE__', __FILE__ );

require_once trailingslashit( dirname( __FILE__ ) ) . 'includes/plugin.php';
